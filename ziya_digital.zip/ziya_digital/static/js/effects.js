/* Ziya Digital: tilt cards, scroll reveal, counters, marquee.
   Everything degrades gracefully. */
(function(){
var RM=matchMedia('(prefers-reduced-motion:reduce)').matches,HOVER=matchMedia('(hover:hover) and (pointer:fine)').matches;
document.documentElement.classList.add('js');
function $$(s){return Array.prototype.slice.call(document.querySelectorAll(s))}

/* scroll progress bar */
var bar=document.createElement('div');bar.className='sp';document.body.appendChild(bar);
function prog(){var h=document.documentElement,m=h.scrollHeight-h.clientHeight;bar.style.transform='scaleX('+(m>0?h.scrollTop/m:0)+')'}
addEventListener('scroll',prog,{passive:true});prog();

/* hero: headline words rise in, services marquee */
var hero=document.querySelector('.hero'),h1=document.querySelector('.hero h1');
if(h1&&!RM){var tx=h1.textContent.trim();h1.setAttribute('aria-label',tx);h1.innerHTML=tx.split(' ').map(function(w,i){return '<span class="w" aria-hidden="true"><span style="animation-delay:'+(.15+i*.07)+'s">'+w+'</span></span>'}).join(' ')}
if(hero){var row=['Website Development','Mobile Apps','Google SEO','Google Ads','Social Media','Branding'].map(function(t){return '<span>'+t+'</span>'}).join(''),mq=document.createElement('div');mq.className='marq';mq.setAttribute('aria-hidden','true');mq.innerHTML='<div class="mt">'+row+row+row+row+'</div>';hero.parentNode.insertBefore(mq,hero.nextSibling)}

/* animated counters */
function count(el){var m=el&&el.textContent.match(/^(\d+)(.*)$/);if(!m)return;var to=+m[1],suf=m[2],t0=performance.now();(function f(t){var p=Math.min(1,(t-t0)/1400),e=1-Math.pow(1-p,3);el.textContent=Math.round(to*e)+suf;if(p<1)requestAnimationFrame(f)})(t0)}

/* scroll reveal with a little 3D tilt-in */
var rv=$$('.card,.step,.head,.srow,.tm,.stats .wrap>div,.panel,.formcard,.cta .wrap,.info,.tile,.faq details,.chips span,.lead .wrap>*');
if('IntersectionObserver' in window&&!RM){
 rv.forEach(function(el){el.classList.add('rv');el.style.transitionDelay=Math.min(Array.prototype.indexOf.call(el.parentNode.children,el),6)*80+'ms'});
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;var el=e.target;el.classList.add('in');io.unobserve(el);if(el.matches('.stats .wrap>div'))count(el.querySelector('strong'));setTimeout(function(){el.classList.remove('rv','in');el.style.transitionDelay=''},1400)})},{threshold:.15});
 rv.forEach(function(el){io.observe(el)});
}

/* 3D tilt + glare on cards */
if(HOVER&&!RM){$$('.grid3 .card,.panel').forEach(function(el){el.classList.add('tilt');
 el.addEventListener('mousemove',function(e){var r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.transform='perspective(900px) rotateY('+x*10+'deg) rotateX('+-y*10+'deg) scale(1.02)';el.style.setProperty('--gx',(x+.5)*100+'%');el.style.setProperty('--gy',(y+.5)*100+'%')});
 el.addEventListener('mouseleave',function(){el.style.transform=''})})}
})();
