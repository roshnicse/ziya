import json
import secrets
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.core.mail import send_mail
from django.db.models import Count, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST

from . import bot
from .models import ChatMessage, ChatSession


def _body(request):
    try:
        return json.loads(request.body or b"{}")
    except ValueError:
        return {}


def _after(request):
    try:
        return int(request.GET.get("after") or 0)
    except ValueError:
        return 0


def _msg(m):
    return {"id": m.id, "sender": m.sender, "text": m.text,
            "options": m.options.split("|") if m.options else [],
            "time": timezone.localtime(m.created_at).strftime("%I:%M %p").lstrip("0")}


def is_online():
    """Mon-Sat, 9:30 am to 6:30 pm India time. Change here if your hours differ."""
    now = datetime.now(ZoneInfo("Asia/Kolkata"))
    minutes = now.hour * 60 + now.minute
    return now.weekday() != 6 and 570 <= minutes < 1110


def _touch(session, message):
    session.last_message_at = message.created_at
    session.save(update_fields=["last_message_at"])


# ---------------- customer side (website chat box) ----------------
@csrf_exempt
@require_POST
def chat_start(request):
    d = _body(request)
    name = str(d.get("name", "")).strip()[:80]
    if not name:
        return JsonResponse({"error": "Please enter your name."}, status=400)
    session = ChatSession.objects.create(
        token=secrets.token_urlsafe(24), name=name,
        phone=str(d.get("phone", "")).strip()[:20])
    _touch(session, bot.greeting(session, is_online()))
    send_mail(
        subject=f"New live chat from {name}",
        message=f"{name} ({session.phone or 'no phone'}) started a chat.\nReply in the support dashboard: /support/",
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[settings.ENQUIRY_NOTIFY_EMAIL], fail_silently=True)
    return JsonResponse({"token": session.token})


@csrf_exempt
@require_POST
def chat_send(request):
    d = _body(request)
    session = ChatSession.objects.filter(token=str(d.get("token", ""))).first()
    text = str(d.get("text", "")).strip()[:1000]
    if not session or not text:
        return JsonResponse({"error": "Message could not be sent."}, status=400)
    recent = session.messages.filter(
        sender="customer", created_at__gte=timezone.now() - timedelta(minutes=1)).count()
    if recent >= 15:
        return JsonResponse({"error": "Please wait a moment before sending more."}, status=429)
    message = ChatMessage.objects.create(session=session, sender="customer", text=text)
    _touch(session, message)
    # Automatic assistant answers, unless a team member replied in the last 10 minutes.
    replies = []
    staff_active = session.messages.filter(
        sender="staff", created_at__gte=timezone.now() - timedelta(minutes=10)).exists()
    if not staff_active:
        replies = [_msg(m) for m in bot.reply(session, text, is_online())]
    return JsonResponse({"message": _msg(message), "bot": replies})


@require_GET
def chat_poll(request):
    session = ChatSession.objects.filter(token=request.GET.get("token", "")).first()
    if not session:
        return JsonResponse({"error": "Unknown chat."}, status=404)
    msgs = [_msg(m) for m in session.messages.filter(id__gt=_after(request))]
    return JsonResponse({"messages": msgs, "online": is_online()})


# ---------------- staff side (support dashboard) ----------------
@staff_member_required
def support_dashboard(request):
    return render(request, "core/support.html")


@staff_member_required
def support_sessions(request):
    qs = ChatSession.objects.annotate(
        unread=Count("messages", filter=Q(messages__sender="customer", messages__seen=False))
    ).order_by("-last_message_at")[:100]
    data = []
    for s in qs:
        last = s.messages.last()
        data.append({"token": s.token, "name": s.name, "phone": s.phone,
                     "unread": s.unread, "needs": s.needs_human, "last": last.text[:60] if last else ""})
    return JsonResponse({"sessions": data})


@staff_member_required
def support_messages(request, token):
    session = get_object_or_404(ChatSession, token=token)
    msgs = list(session.messages.filter(id__gt=_after(request)))
    session.messages.filter(sender="customer", seen=False).update(seen=True)
    return JsonResponse({"messages": [_msg(m) for m in msgs]})


@staff_member_required
@require_POST
def support_reply(request, token):
    session = get_object_or_404(ChatSession, token=token)
    text = str(_body(request).get("text", "")).strip()[:1000]
    if not text:
        return JsonResponse({"error": "Empty reply."}, status=400)
    message = ChatMessage.objects.create(session=session, sender="staff", text=text, seen=True)
    session.needs_human = False
    session.save(update_fields=["needs_human"])
    _touch(session, message)
    return JsonResponse({"message": _msg(message)})
