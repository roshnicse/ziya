from django.contrib import admin
from . import models


@admin.register(models.Enquiry)
class EnquiryAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "email", "service", "status", "created_at")
    list_editable = ("status",)
    list_filter = ("status", "service")
    search_fields = ("name", "phone", "email", "message")


@admin.register(models.SeoAudit)
class SeoAuditAdmin(admin.ModelAdmin):
    list_display = ("website_url", "email", "done", "created_at")
    list_editable = ("done",)


@admin.register(models.Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ("title", "order")
    prepopulated_fields = {"slug": ("title",)}


@admin.register(models.BlogPost)
class BlogPostAdmin(admin.ModelAdmin):
    list_display = ("title", "is_published", "published_at")
    prepopulated_fields = {"slug": ("title",)}


admin.site.register(models.Package)
admin.site.register(models.Testimonial)
admin.site.register(models.PortfolioItem)
admin.site.register(models.TeamMember)


class ChatMessageInline(admin.TabularInline):
    model = models.ChatMessage
    extra = 0
    readonly_fields = ("sender", "text", "created_at")
    can_delete = False


@admin.register(models.ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "needs_human", "created_at", "last_message_at")
    search_fields = ("name", "phone")
    inlines = [ChatMessageInline]
