from django.urls import path
from . import chat, views

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("services/", views.services_list, name="services"),
    path("contact/", views.contact, name="contact"),
    path("services/<slug:slug>/", views.service_detail, name="service_detail"),
    path("blog/", views.blog_list, name="blog_list"),
    path("blog/<slug:slug>/", views.blog_detail, name="blog_detail"),
    path("quote/", views.quote, name="quote"),
    path("audit/", views.audit, name="audit"),
    path("chat/start/", chat.chat_start, name="chat_start"),
    path("chat/send/", chat.chat_send, name="chat_send"),
    path("chat/poll/", chat.chat_poll, name="chat_poll"),
    path("support/", chat.support_dashboard, name="support"),
    path("support/api/sessions/", chat.support_sessions, name="support_sessions"),
    path("support/api/messages/<str:token>/", chat.support_messages, name="support_messages"),
    path("support/api/reply/<str:token>/", chat.support_reply, name="support_reply"),
]
