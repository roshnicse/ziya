from django.db import models
from django.urls import reverse
from django.utils import timezone


class Service(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    icon = models.CharField(max_length=4, help_text="1-2 letters shown in the icon box")
    short_desc = models.CharField(max_length=200)
    description = models.TextField()
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "title"]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("service_detail", args=[self.slug])


class Package(models.Model):
    service = models.ForeignKey(Service, null=True, blank=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=60)
    price = models.DecimalField(max_digits=9, decimal_places=0)
    features = models.TextField(help_text="One feature per line")
    popular = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "price"]

    def __str__(self):
        return self.name

    def feature_list(self):
        return [f.strip() for f in self.features.splitlines() if f.strip()]


class Testimonial(models.Model):
    client_name = models.CharField(max_length=80)
    company = models.CharField(max_length=80, blank=True)
    review = models.TextField()
    rating = models.PositiveSmallIntegerField(default=5)

    def __str__(self):
        return f"{self.client_name} ({self.company})"


class PortfolioItem(models.Model):
    title = models.CharField(max_length=100)
    client = models.CharField(max_length=80)
    category = models.CharField(max_length=60)
    description = models.TextField()
    result = models.CharField(max_length=120, blank=True, help_text="e.g. Enquiries up 3x")
    image = models.ImageField(upload_to="portfolio/", blank=True)

    def __str__(self):
        return self.title


class TeamMember(models.Model):
    name = models.CharField(max_length=80)
    role = models.CharField(max_length=80)
    photo = models.ImageField(upload_to="team/", blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return self.name

    def initials(self):
        return "".join(p[0] for p in self.name.split()[:2]).upper()


class BlogPost(models.Model):
    title = models.CharField(max_length=160)
    slug = models.SlugField(unique=True)
    content = models.TextField()
    image = models.ImageField(upload_to="blog/", blank=True)
    meta_title = models.CharField(max_length=70, blank=True)
    meta_description = models.CharField(max_length=160, blank=True)
    is_published = models.BooleanField(default=True)
    published_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-published_at"]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("blog_detail", args=[self.slug])


class Enquiry(models.Model):
    STATUS = [("new", "New"), ("contacted", "Contacted"), ("won", "Won"), ("lost", "Lost")]
    name = models.CharField(max_length=80)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20)
    service = models.ForeignKey(Service, null=True, blank=True, on_delete=models.SET_NULL)
    message = models.TextField(blank=True)
    status = models.CharField(max_length=12, choices=STATUS, default="new")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name_plural = "enquiries"

    def __str__(self):
        return f"{self.name} - {self.phone}"


class SeoAudit(models.Model):
    website_url = models.URLField()
    email = models.EmailField(blank=True)
    done = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.website_url


class ChatSession(models.Model):
    token = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=80)
    phone = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_message_at = models.DateTimeField(default=timezone.now)
    needs_human = models.BooleanField(default=False, help_text="Assistant could not answer; a person should reply")
    flow_step = models.IntegerField(default=-1)
    flow_data = models.TextField(blank=True, default="{}")

    class Meta:
        ordering = ["-last_message_at"]

    def __str__(self):
        return f"{self.name} ({self.created_at:%d %b %Y %H:%M})"


class ChatMessage(models.Model):
    SENDER = [("customer", "Customer"), ("staff", "Staff"), ("bot", "Auto assistant")]
    session = models.ForeignKey(ChatSession, related_name="messages", on_delete=models.CASCADE)
    sender = models.CharField(max_length=8, choices=SENDER)
    text = models.TextField()
    options = models.CharField(max_length=300, blank=True, help_text="Quick-reply buttons, separated by |")
    seen = models.BooleanField(default=False, help_text="Customer messages: read by staff")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"{self.sender}: {self.text[:40]}"
