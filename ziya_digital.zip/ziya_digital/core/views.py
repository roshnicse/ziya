from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import AuditForm, EnquiryForm
from .models import (BlogPost, Package, PortfolioItem, Service, TeamMember,
                     Testimonial)


def home(request):
    return render(request, "core/home.html", {
        "services": Service.objects.all(),
        "packages": Package.objects.filter(service__isnull=True),
        "testimonials": Testimonial.objects.all()[:3],
        "portfolio": PortfolioItem.objects.all()[:3],
        "audit_form": AuditForm(),
    })


def about(request):
    return render(request, "core/about.html", {"team": TeamMember.objects.all()})


def services_list(request):
    return render(request, "core/services.html", {"services": Service.objects.all()})


def contact(request):
    return render(request, "core/contact.html", {"form": EnquiryForm()})


def service_detail(request, slug):
    service = get_object_or_404(Service, slug=slug)
    return render(request, "core/service_detail.html", {
        "service": service,
        "packages": service.package_set.all(),
        "form": EnquiryForm(initial={"service": service}),
    })


def blog_list(request):
    return render(request, "core/blog_list.html",
                  {"posts": BlogPost.objects.filter(is_published=True)})


def blog_detail(request, slug):
    post = get_object_or_404(BlogPost, slug=slug, is_published=True)
    return render(request, "core/blog_detail.html", {"post": post})


@require_POST
def quote(request):
    form = EnquiryForm(request.POST)
    if form.is_valid():
        enquiry = form.save()
        send_mail(
            subject=f"New enquiry from {enquiry.name}",
            message=(f"Name: {enquiry.name}\nPhone: {enquiry.phone}\n"
                     f"Email: {enquiry.email}\nService: {enquiry.service}\n\n"
                     f"{enquiry.message}"),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.ENQUIRY_NOTIFY_EMAIL],
            fail_silently=True,
        )
        messages.success(request, "Thank you! We will contact you within one working day.")
    else:
        messages.error(request, "Please enter your name and a phone number.")
    return redirect("contact")


@require_POST
def audit(request):
    form = AuditForm(request.POST)
    if form.is_valid():
        obj = form.save()
        send_mail(
            subject="New SEO audit request",
            message=f"Website: {obj.website_url}\nEmail: {obj.email}",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.ENQUIRY_NOTIFY_EMAIL],
            fail_silently=True,
        )
        messages.success(request, "Audit request received. We will email your report soon.")
    else:
        messages.error(request, "Please enter a valid website address, starting with https://")
    return redirect("/#audit")
