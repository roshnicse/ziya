from django.core.management.base import BaseCommand
from core.models import (BlogPost, Package, PortfolioItem, Service, TeamMember,
                         Testimonial)


class Command(BaseCommand):
    help = "Add sample content so the site is not empty"

    def handle(self, *args, **opts):
        services = [
            ("Website Development", "website-development", "W", "Fast, mobile-friendly business sites and online stores.",
             "We design and build websites that load fast, look professional and turn visitors into enquiries. Includes SEO-ready structure, contact forms and an admin panel."),
            ("Mobile App Development", "mobile-app-development", "A", "Android and iOS apps built around your customers.",
             "From booking apps to delivery apps, we plan, design and launch mobile apps for Android and iOS."),
            ("Google SEO", "google-seo", "S", "Rank higher on Google without paying per click.",
             "Keyword research, on-page fixes, local SEO and monthly reports so your business appears when customers search."),
            ("Google Ads", "google-ads", "Ad", "Paid campaigns that bring calls from day one.",
             "We set up and manage Google Ads campaigns, track every lead and lower your cost per enquiry over time."),
            ("Social Media Management", "social-media-management", "Sm", "Posts, reels and replies handled every week.",
             "Content calendar, designs, posting and community replies for Instagram, Facebook and LinkedIn."),
        ]
        for i, (t, s, ic, short, desc) in enumerate(services):
            Service.objects.get_or_create(slug=s, defaults=dict(
                title=t, icon=ic, short_desc=short, description=desc, order=i))

        if not Package.objects.exists():
            Package.objects.create(name="Starter", price=9999, order=1,
                features="5-page website\nContact form\nBasic SEO setup")
            Package.objects.create(name="Growth", price=24999, order=2, popular=True,
                features="10-page website\nMonthly SEO\nGoogle Ads setup")
            Package.objects.create(name="Premium", price=49999, order=3,
                features="Website or app\nSEO, Ads and social media\nMonthly report")

        if not Testimonial.objects.exists():
            Testimonial.objects.create(client_name="Ravi", company="Textile shop",
                review="Our enquiries doubled within four months of starting SEO.")
            Testimonial.objects.create(client_name="Meena", company="Clinic",
                review="The app was delivered on time and our customers love it.")
            Testimonial.objects.create(client_name="Karthik", company="Interior designer",
                review="Google Ads brought calls from the very first week.")

        if not PortfolioItem.objects.exists():
            PortfolioItem.objects.create(title="Local bakery website", client="Bakery", category="Website + SEO",
                description="New website and Google SEO.", result="Enquiries up 3x in 4 months")
            PortfolioItem.objects.create(title="Clinic booking app", client="Clinic", category="Mobile app",
                description="Android app with online appointments.", result="800+ bookings in month one")
            PortfolioItem.objects.create(title="Interior design ads", client="Interior designer", category="Google Ads",
                description="Google Ads campaign.", result="Cost per lead down 40%")

        if not TeamMember.objects.exists():
            for i, (n, r) in enumerate([("Zia A", "Founder and strategy"), ("Dev V", "Lead developer"),
                                        ("Seo E", "SEO and Ads expert"), ("Sam M", "Social media designer")]):
                TeamMember.objects.create(name=n, role=r, order=i)

        BlogPost.objects.get_or_create(slug="how-to-rank-on-googles-first-page", defaults=dict(
            title="How to rank on Google's first page",
            meta_description="Five steps small businesses can start this week to rank higher on Google.",
            content="1. Add your business to Google Business Profile.\n\n2. Use the words customers search in your page titles.\n\n3. Make your website fast on mobile.\n\n4. Get reviews from happy customers.\n\n5. Publish helpful articles every month."))
        self.stdout.write(self.style.SUCCESS("Sample content added."))
