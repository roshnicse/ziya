"""Automatic assistant for the live chat.
Answers general questions (services, prices, timelines, contact), collects website
requirements step by step, and hands over to your team when it cannot help.
Edit core/bot_data.json to change answers, prices and questions."""
import json
import re
from pathlib import Path

from django.conf import settings
from django.core.mail import send_mail

from .models import ChatMessage, Enquiry

DATA = json.loads((Path(__file__).parent / "bot_data.json").read_text(encoding="utf-8"))


class _Safe(dict):
    def __missing__(self, key):
        return "{" + key + "}"


def _fill(text, session):
    return text.format_map(_Safe(
        name=session.name, site=settings.SITE_NAME, phone=settings.SITE_PHONE,
        email=settings.SITE_EMAIL, address=settings.SITE_ADDRESS))


def _save(session, text, options=None):
    return ChatMessage.objects.create(
        session=session, sender="bot", seen=True,
        text=_fill(text, session), options="|".join(options or []))


def _state(session):
    session.save(update_fields=["needs_human", "flow_step", "flow_data", "phone"])


def _match(text):
    for intent in DATA["intents"]:
        for k in intent["keywords"]:
            pattern = r"\b" + re.escape(k) + (r"\b" if intent.get("exact") else "")
            if re.search(pattern, text, re.I):
                return intent
    return None


def greeting(session, online):
    return _save(session, DATA["greeting_online" if online else "greeting_offline"], DATA["main"])


def reply(session, text, online):
    """Return the list of bot ChatMessage objects created for this customer message."""
    out = [_save(session, body, options) for body, options in _respond(session, text.strip(), online)]
    if out:
        session.last_message_at = out[-1].created_at
        session.save(update_fields=["last_message_at"])
    return out


def _respond(session, text, online):
    if session.flow_step >= 0:
        if re.search(r"\b(cancel|stop|skip|never mind)\b", text, re.I):
            session.flow_step = -1
            _state(session)
            return [(DATA["flow"]["cancel"], DATA["main"])]
        return _flow(session, text)

    intent = _match(text)
    if intent is None:
        session.needs_human = True
        _state(session)
        return [(DATA["fallback_online" if online else "fallback_offline"], DATA["main"])]
    if intent.get("action") == "human":
        session.needs_human = True
        _state(session)
        return [(DATA["human_online" if online else "human_offline"], [])]
    if intent.get("action") == "flow":
        session.flow_step, session.flow_data = 0, "{}"
        _state(session)
        first = DATA["flow"]["steps"][0]
        return [(DATA["flow"]["intro"] + " " + first["q"], first.get("options", []))]
    return [(intent["answer"], intent.get("options", DATA["main"]))]


def _flow(session, text):
    steps = DATA["flow"]["steps"]
    data = json.loads(session.flow_data or "{}")
    step = steps[session.flow_step]
    if step["key"] == "phone":
        if len(re.sub(r"\D", "", text)) < 8:
            return [("That does not look like a phone number. Please type it again with the country code.", [])]
        session.phone = text[:20]
    data[step["key"]] = text[:300]
    nxt = session.flow_step + 1
    if nxt < len(steps) and steps[nxt]["key"] == "phone" and session.phone:
        nxt += 1
    if nxt >= len(steps):
        return _finish(session, data)
    session.flow_step, session.flow_data = nxt, json.dumps(data)
    _state(session)
    return [(steps[nxt]["q"], steps[nxt].get("options", []))]


def _finish(session, data):
    lines = [f"{s['label']}: {data.get(s['key'], '-')}" for s in DATA["flow"]["steps"] if s["key"] != "phone"]
    summary = "Source: live chat assistant\n" + "\n".join(lines)
    Enquiry.objects.create(name=session.name, phone=session.phone or "-", message=summary)
    send_mail(
        subject=f"New requirements from {session.name} (live chat)",
        message=f"{session.name}, {session.phone}\n\n{summary}",
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[settings.ENQUIRY_NOTIFY_EMAIL], fail_silently=True)
    session.flow_step, session.flow_data, session.needs_human = -1, "{}", True
    _state(session)
    return [(DATA["flow"]["done"], DATA["main"])]
