from django import forms
from .models import Enquiry, SeoAudit


class EnquiryForm(forms.ModelForm):
    class Meta:
        model = Enquiry
        fields = ["name", "phone", "email", "service", "message"]
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "Your name"}),
            "phone": forms.TextInput(attrs={"placeholder": "Phone number", "type": "tel"}),
            "email": forms.EmailInput(attrs={"placeholder": "Email (optional)"}),
            "message": forms.Textarea(attrs={"rows": 3, "placeholder": "Tell us about your project"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["service"].empty_label = "Choose a service"


class AuditForm(forms.ModelForm):
    class Meta:
        model = SeoAudit
        fields = ["website_url", "email"]
        widgets = {
            "website_url": forms.URLInput(attrs={"placeholder": "https://yourwebsite.com"}),
            "email": forms.EmailInput(attrs={"placeholder": "Email for the report"}),
        }
