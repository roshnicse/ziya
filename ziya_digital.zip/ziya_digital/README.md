# Ziya Digital Solutions - Django + MySQL website

## 1. Install
    python -m venv venv
    venv\Scripts\activate          (Windows)   |   source venv/bin/activate  (Mac/Linux)
    pip install -r requirements.txt

(mysqlclient on Windows: if install fails, use `pip install mysqlclient` with a wheel from
https://pypi.org/project/mysqlclient/ or install the MySQL C connector first.)

## 2. Create the MySQL database
    CREATE DATABASE ziya_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

## 3. Set your database login (or edit ziya_digital/settings.py)
    set DB_NAME=ziya_db
    set DB_USER=root
    set DB_PASSWORD=your_mysql_password
(Mac/Linux: use `export` instead of `set`)

## 4. Create tables, admin user, sample content
    python manage.py makemigrations core
    python manage.py migrate
    python manage.py createsuperuser
    python manage.py seed

## 5. Run
    python manage.py runserver
Website: http://127.0.0.1:8000/     Admin: http://127.0.0.1:8000/admin/

## Where to change things
- Phone, WhatsApp, email, address: ziya_digital/settings.py (bottom)
- Colours: static/css/style.css (top :root block)
- Header and footer: templates/core/_header.html and _footer.html (shown on every page)
- Pages: home.html, about.html, services.html, contact.html in templates/core
- Services, prices, blog, portfolio, enquiries: Admin panel
- Enquiry emails: set EMAIL_HOST, EMAIL_HOST_USER, EMAIL_HOST_PASSWORD, ENQUIRY_NOTIFY_EMAIL.
  Without them, emails print in the terminal.

## Go live
Set DEBUG=0, a strong SECRET_KEY, ALLOWED_HOSTS=yourdomain.com, run
`python manage.py collectstatic`, and serve with gunicorn + nginx on a VPS.

## Live chat (customers chat on the website, your team replies in the same chat box)
- Customers click "Chat with support", enter their name and chat inside the website.
- Your team replies at  http://127.0.0.1:8000/support/  (log in with the admin user you created).
  Keep this page open during working hours. New messages show a red count and the browser tab title.
- You also get an email when a new chat starts (see email settings above).
- Past chats are stored in MySQL and visible in Admin > Chat sessions.
- Working hours shown to customers: edit is_online() in core/chat.py.
- Run `python manage.py makemigrations core` and `migrate` again so the chat tables are created.

## Automatic assistant (answers when your team has not replied)
- Inside the live chat, an automatic assistant answers general questions at once: services, prices,
  timelines, process, portfolio, contact details and hours.
- It can also collect website requirements step by step (business type, what is needed, details, budget,
  timeline, phone). The answers are saved as an Enquiry (Admin > Enquiries) and emailed to you.
- If it cannot answer, or the customer asks for a person, the chat is marked "Needs reply" in /support/.
- While a team member is replying (last 10 minutes), the assistant stays silent.
- To change answers, prices, questions and keywords, edit core/bot_data.json (no code needed).
  The prices, results and hours in it are SAMPLES: replace them with your real details.
- Run `python manage.py makemigrations core` and `migrate` again after updating.

## 3D and animation effects
- Cards tilt in 3D under the mouse, sections animate in on scroll, numbers count up,
  a services strip scrolls under the hero, and a gold progress bar follows your scroll.
- Code: static/js/effects.js and the bottom of static/css/style.css.
- Visitors who prefer reduced motion see a still version. 
